package utils;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

public class MainWindow extends JFrame {
    private HangmanPanel drawingPanel;
    private JLabel wordLabel;
    private JLabel statusLabel;
    private JTextField inputField;
    private JButton guessButton;
    private JPanel gamePanel;
    private JPanel setupPanel;

    // Model
    private HangmanGame game;

    public MainWindow() {
        super("Hangman Game - Player 2 Turn");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        
        initSetupScreen(); 
    }

   
    private void initSetupScreen() {
        setupPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        setupPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Player 1: Setup Game", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        
        JTextField secretWordField = new JTextField();
        secretWordField.setBorder(BorderFactory.createTitledBorder("Secret Word (English only)"));
        
        JSpinner triesSpinner = new JSpinner(new SpinnerNumberModel(6, 1, 15, 1));
        triesSpinner.setBorder(BorderFactory.createTitledBorder("Max Tries"));

        JButton startButton = new JButton("Start Game");

        setupPanel.add(title);
        setupPanel.add(secretWordField);
        setupPanel.add(triesSpinner);
        setupPanel.add(startButton);

        this.add(setupPanel);

        
        startButton.addActionListener(e -> {
            String word = secretWordField.getText().trim();
            int tries = (int) triesSpinner.getValue();

           
            if (HangmanGame.validateWord(word) && !word.isEmpty()) {
                
                game = new HangmanGame(word, tries);
               
                this.remove(setupPanel);
                initGameScreen(tries); 
                this.revalidate();
                this.repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid word! Use English letters only.");
            }
        });
    }

  
    private void initGameScreen(int maxTries) {
        gamePanel = new JPanel(new BorderLayout());

        
        drawingPanel = new HangmanPanel();
        gamePanel.add(drawingPanel, BorderLayout.CENTER);

       
        wordLabel = new JLabel(game.getWordState(), SwingConstants.CENTER);
        wordLabel.setFont(new Font("Monospaced", Font.BOLD, 24)); 
        wordLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        gamePanel.add(wordLabel, BorderLayout.NORTH);

        JPanel controls = new JPanel();
        statusLabel = new JLabel("Mistakes: 0/" + maxTries + " ");
        inputField = new JTextField(3);
        guessButton = new JButton("Guess");

        controls.add(statusLabel);
        controls.add(new JLabel("Type letter:"));
        controls.add(inputField);
        controls.add(guessButton);
        
        gamePanel.add(controls, BorderLayout.SOUTH);
        this.add(gamePanel);

       
        guessButton.addActionListener(e -> handleGuess());
       
        inputField.addActionListener(e -> handleGuess());
    }

  
    private void handleGuess() {
        String text = inputField.getText();
        if (text.length() > 0) {
            char letter = text.charAt(0);
            
           
            boolean hit = game.guess(letter); 
            
         
            wordLabel.setText(game.getWordState());
            drawingPanel.setMistakes(game.getCurrentMistakes(), 6);
            statusLabel.setText("Mistakes: " + game.getCurrentMistakes() + " ");
            inputField.setText("");
            inputField.requestFocus();

         
            if (game.isWon()) {
                JOptionPane.showMessageDialog(this, "YOU WON! The word was: " + game.getSecretWord());
                resetGame();
            } else if (game.isLost()) {
                JOptionPane.showMessageDialog(this, "GAME OVER. You died. The word was: " + game.getSecretWord());
                resetGame();
            }
        }
    }

    private void resetGame() {

        this.remove(gamePanel);
        this.add(setupPanel);
        this.revalidate();
        this.repaint();
    }
}