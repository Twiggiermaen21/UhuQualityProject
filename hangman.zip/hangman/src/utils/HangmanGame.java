package utils;

import java.util.HashSet;
import java.util.Set;

public class HangmanGame {
    private String secretWord;
    private StringBuilder wordState; 
    private int maxTries;
    private int currentMistakes;
    private Set<Character> guessedLetters;

    public HangmanGame(String word, int maxTries) {
        this.secretWord = word.toUpperCase();
        this.maxTries = maxTries;
        this.currentMistakes = 0;
        this.guessedLetters = new HashSet<>();
        
        
        this.wordState = new StringBuilder();
        for (int i = 0; i < secretWord.length(); i++) {
            
            if (secretWord.charAt(i) == ' ') {
                wordState.append(" ");
            } else {
                wordState.append("*");
            }
        }
    }


    public boolean guess(char letter) {
        letter = Character.toUpperCase(letter);
        
        
        if (guessedLetters.contains(letter)) {
            return false; 
        }
        guessedLetters.add(letter);

        boolean isHit = false;

        for (int i = 0; i < secretWord.length(); i++) {
            if (secretWord.charAt(i) == letter) {
                wordState.setCharAt(i, letter);
                isHit = true;
            }
        }

        if (!isHit) {
            currentMistakes++;
        }

        return isHit; 
    }

    public static boolean validateWord(String word) {
        return word.matches("[a-zA-Z ]+");
    }

    public String getWordState() {
        return wordState.toString();
    }

    public boolean isGameOver() {
        return isWon() || isLost();
    }

    public boolean isWon() {
        return wordState.toString().equals(secretWord);
    }

    public boolean isLost() {
        return currentMistakes >= maxTries;
    }

    public int getCurrentMistakes() {
        return currentMistakes;
    }
    
    public String getSecretWord() {
        return secretWord;
    }
}