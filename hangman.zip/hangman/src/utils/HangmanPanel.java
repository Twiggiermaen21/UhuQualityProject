package utils;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class HangmanPanel extends JPanel {
    private int mistakes = 0;
    private int maxMistakes = 6; 

    public HangmanPanel() {
        this.setPreferredSize(new Dimension(300, 300));
        this.setBackground(Color.WHITE);
    }

    public void setMistakes(int mistakes, int maxMistakes) {
        this.mistakes = mistakes;
        this.maxMistakes = maxMistakes;
        repaint(); 
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(3)); 
        g2.setColor(Color.BLACK);

       
        g2.drawLine(50, 250, 250, 250); 
        g2.drawLine(100, 250, 100, 50); 
        g2.drawLine(100, 50, 200, 50);  
        g2.drawLine(200, 50, 200, 80); 

        
        if (mistakes > 0) g2.drawOval(180, 80, 40, 40); 
        if (mistakes > 1) g2.drawLine(200, 120, 200, 200); 
        if (mistakes > 2) g2.drawLine(200, 140, 170, 180); 
        if (mistakes > 3) g2.drawLine(200, 140, 230, 180); 
        if (mistakes > 4) g2.drawLine(200, 200, 170, 240); 
        if (mistakes > 5) g2.drawLine(200, 200, 230, 240); 
        
        
    }
}